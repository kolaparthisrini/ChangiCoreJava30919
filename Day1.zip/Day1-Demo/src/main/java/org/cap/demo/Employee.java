package org.cap.demo;

public class Employee {
	
	//Instance variable
	String firstName;
	boolean isPermanent;
	int empId;
	char gender;
	double salary;
	byte empTempId;
	
	
	public double calculateBonus() {
		//local variable
		double bonus;
		bonus=salary * .50;
		return bonus;
	}
	
	
	public static void main(String[] args) {
		Employee employee=new Employee();
		System.out.println(employee.empId);
		System.out.println(employee.empTempId);
		System.out.println(employee.firstName);
		System.out.println(employee.gender);
		System.out.println(employee.salary);
		System.out.println(employee.isPermanent);
		
		System.out.println("Bonus: " + employee.calculateBonus());
		
	}

}
