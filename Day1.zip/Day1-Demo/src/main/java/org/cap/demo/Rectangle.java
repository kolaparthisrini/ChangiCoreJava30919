package org.cap.demo;

import java.util.Scanner;

public class Rectangle {

	double height;
	double width;
	
	
	public void caculateArea() {
		System.out.println("Area is: " + height*width);
	}
	
	public static void main(String[] args) {
		Rectangle rect=new Rectangle();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Height:");
		rect.height=sc.nextDouble();
		
		System.out.println("Enter Width:");
		rect.width=sc.nextDouble();
		
		
		rect.caculateArea();

	}

}
